import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styles: ['./breadcrumb.component.less']
})
export class BreadcrumbComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
