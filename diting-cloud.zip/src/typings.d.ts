// # 3rd Party Library
// If the library doesn't have typings available at `@types/`,
// you can still use it by manually adding typings for it

// G2
declare var G2: any;
declare var DataSet: any;
declare var Slider: any;
declare var BMapGL: any;
declare var common: {
    initMap(): void;
    snowStyle: any;
    darkStyle: any;
    purpleStyle: any;
    whiteStyle: any
};
